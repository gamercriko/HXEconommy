# HexaEconomy (HexaMC)

Target: Paper/Purpur 26.2, Java 25, Maven 3.9+.

## Build
Install JDK 25 and Maven 3.9+, then run:
```sh
mvn -U clean package
```
Output: `target/HexaEconomy.jar`

## Install
1. Back up your server and `plugins/` directory.
2. Copy `target/HexaEconomy.jar` to `plugins/`.
3. Start the server once, then edit `plugins/HexaEconomy/config.yml`, `shop.yml`, and `messages.yml`.
4. Restart after configuration changes.

## Current implementation scope
This source package implements the base SQLite ledger, balance/pay/admin commands, cached baltop, category/quantity/confirmation shop GUIs, and sell-deposit GUI. Auction-house and buy-order GUIs/tables are only schema groundwork and are not yet implemented as player workflows. This has not been compiled or integration-tested in this environment. Do not treat it as a production-audited anti-exploit release; test on a staging server with backups first.
