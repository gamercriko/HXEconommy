package net.hexamc.hexaeconomy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ColorUtil {
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
    private ColorUtil() {}
    public static Component component(String input) {
        return input == null || input.isEmpty() ? Component.empty() : LEGACY.deserialize(legacy(input));
    }
    public static String legacy(String input) {
        if (input == null) return "";
        Matcher m = HEX.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String h = m.group(1);
            StringBuilder code = new StringBuilder("§x");
            for (char c : h.toCharArray()) code.append('§').append(c);
            m.appendReplacement(out, Matcher.quoteReplacement(code.toString()));
        }
        m.appendTail(out);
        return out.toString().replace('&', '§');
    }
}
