package net.hexamc.hexaeconomy;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.io.File;
import java.sql.*;
import java.util.UUID;

public final class DatabaseManager implements AutoCloseable {
    private final HikariDataSource pool;
    public DatabaseManager(HexaEconomy plugin) {
        File file = new File(plugin.getDataFolder(), plugin.getConfig().getString("database.file", "economy.db"));
        HikariConfig cfg = new HikariConfig();
        cfg.setPoolName("HexaEconomy-SQLite");
        cfg.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
        cfg.setMaximumPoolSize(Math.max(2, Math.min(10, plugin.getConfig().getInt("database.pool-size", 10))));
        cfg.setMinimumIdle(2);
        cfg.setConnectionTestQuery("SELECT 1");
        cfg.addDataSourceProperty("journal_mode", "WAL");
        cfg.addDataSourceProperty("busy_timeout", "5000");
        cfg.addDataSourceProperty("foreign_keys", "true");
        pool = new HikariDataSource(cfg);
        try (Connection c = pool.getConnection(); Statement s = c.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");
            s.execute("PRAGMA synchronous=NORMAL");
            s.execute("PRAGMA busy_timeout=5000");
            s.execute("PRAGMA foreign_keys=ON");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS accounts(uuid TEXT PRIMARY KEY, name TEXT NOT NULL, balance BIGINT NOT NULL CHECK(balance >= 0), updated_at INTEGER NOT NULL)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, target TEXT, amount BIGINT NOT NULL CHECK(amount > 0), kind TEXT NOT NULL, created_at INTEGER NOT NULL)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS auctions(listing_id INTEGER PRIMARY KEY AUTOINCREMENT, seller_uuid TEXT NOT NULL, seller_name TEXT NOT NULL, serialized_item TEXT NOT NULL, price BIGINT NOT NULL CHECK(price > 0), created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, is_active INTEGER NOT NULL DEFAULT 1, is_claimed INTEGER NOT NULL DEFAULT 0)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS orders(order_id INTEGER PRIMARY KEY AUTOINCREMENT, owner_uuid TEXT NOT NULL, owner_name TEXT NOT NULL, material TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0), unit_price BIGINT NOT NULL CHECK(unit_price > 0), escrow BIGINT NOT NULL CHECK(escrow >= 0), created_at INTEGER NOT NULL, is_active INTEGER NOT NULL DEFAULT 1)");
        } catch (SQLException e) { throw new IllegalStateException("Could not initialize HexaEconomy database", e); }
    }
    public Connection connection() throws SQLException { return pool.getConnection(); }
    public long loadBalance(UUID id, String name, long starting) throws SQLException {
        try (Connection c=connection(); PreparedStatement q=c.prepareStatement("SELECT balance FROM accounts WHERE uuid=?")) {
            q.setString(1,id.toString()); try(ResultSet r=q.executeQuery()) { if(r.next()) return r.getLong(1); }
        }
        try(Connection c=connection(); PreparedStatement p=c.prepareStatement("INSERT OR IGNORE INTO accounts(uuid,name,balance,updated_at) VALUES(?,?,?,?)")) {
            p.setString(1,id.toString()); p.setString(2,name); p.setLong(3,starting); p.setLong(4,System.currentTimeMillis()); p.executeUpdate();
        }
        return starting;
    }
    public void save(UUID id, String name, long balance) throws SQLException {
        try(Connection c=connection(); PreparedStatement p=c.prepareStatement("INSERT INTO accounts(uuid,name,balance,updated_at) VALUES(?,?,?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,balance=excluded.balance,updated_at=excluded.updated_at")) {
            p.setString(1,id.toString()); p.setString(2,name); p.setLong(3,Math.max(0,balance)); p.setLong(4,System.currentTimeMillis()); p.executeUpdate();
        }
    }
    public void audit(UUID actor, UUID target, long amount, String kind) throws SQLException {
        try(Connection c=connection(); PreparedStatement p=c.prepareStatement("INSERT INTO transactions(actor,target,amount,kind,created_at) VALUES(?,?,?,?,?)")) {
            p.setString(1,actor==null?null:actor.toString()); p.setString(2,target.toString()); p.setLong(3,amount); p.setString(4,kind); p.setLong(5,System.currentTimeMillis()); p.executeUpdate();
        }
    }
    public boolean healthy() { try(Connection c=connection(); Statement s=c.createStatement(); ResultSet r=s.executeQuery("SELECT 1")) { return r.next(); } catch(SQLException e) { return false; } }
    @Override public void close() { if(pool!=null) pool.close(); }
}
