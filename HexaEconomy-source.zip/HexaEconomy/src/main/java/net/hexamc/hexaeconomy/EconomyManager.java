package net.hexamc.hexaeconomy;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

public final class EconomyManager {
    private final HexaEconomy plugin;
    private final DatabaseManager db;
    private final ConcurrentHashMap<UUID, AtomicLong> balances = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<UUID, String> names = new ConcurrentHashMap<>();
    private final ExecutorService io = Executors.newFixedThreadPool(2, Thread.ofPlatform().name("HexaEconomy-DB-",0).factory());
    private final long starting;
    public EconomyManager(HexaEconomy plugin, DatabaseManager db) {
        this.plugin=plugin; this.db=db;
        this.starting=toCents(BigDecimal.valueOf(plugin.getConfig().getDouble("starting-balance",100)));
    }
    public static long toCents(BigDecimal value) { return value.setScale(2,RoundingMode.UNNECESSARY).movePointRight(2).longValueExact(); }
    public static String money(long cents) { return BigDecimal.valueOf(cents,2).setScale(2).toPlainString(); }
    public CompletableFuture<Long> load(UUID id, String name) {
        return CompletableFuture.supplyAsync(() -> {
            try { long b=db.loadBalance(id,name,starting); balances.put(id,new AtomicLong(b)); names.put(id,name); return b; }
            catch(SQLException e) { throw new CompletionException(e); }
        },io);
    }
    public long balance(UUID id) { AtomicLong a=balances.get(id); return a==null?0:a.get(); }
    public boolean loaded(UUID id) { return balances.containsKey(id); }
    public CompletableFuture<Long> ensure(OfflinePlayer p) {
        if(loaded(p.getUniqueId())) return CompletableFuture.completedFuture(balance(p.getUniqueId()));
        return load(p.getUniqueId(), p.getName()==null?"Unknown":p.getName());
    }
    public CompletableFuture<Boolean> transfer(UUID from, String fromName, UUID to, String toName, long amount) {
        return CompletableFuture.supplyAsync(() -> {
            if(amount<=0 || from.equals(to)) return false;
            synchronized (lockFor(from,to)) {
                try {
                    long a=db.loadBalance(from,fromName,starting), b=db.loadBalance(to,toName,starting);
                    if(a<amount) return false;
                    db.save(from,fromName,a-amount); db.save(to,toName,Math.addExact(b,amount));
                    db.audit(from,to,amount,"PAY");
                    balances.put(from,new AtomicLong(a-amount)); balances.put(to,new AtomicLong(Math.addExact(b,amount)));
                    names.put(from,fromName); names.put(to,toName); return true;
                } catch(Exception e) { plugin.getLogger().severe("Transfer failed: "+e.getMessage()); return false; }
            }
        },io);
    }
    private Object lockFor(UUID a, UUID b) { return (a.compareTo(b)<=0?a:b).toString().intern(); }
    public CompletableFuture<Long> modify(UUID id,String name,String action,long amount) {
        return CompletableFuture.supplyAsync(() -> {
            synchronized (id.toString().intern()) {
                try {
                    long old=db.loadBalance(id,name,starting);
                    long next=switch(action.toLowerCase(Locale.ROOT)) {
                        case "give" -> Math.addExact(old,amount);
                        case "take" -> Math.max(0,old-amount);
                        case "set" -> Math.max(0,amount);
                        case "reset" -> starting;
                        default -> old;
                    };
                    db.save(id,name,next); db.audit(null,id,Math.max(1,Math.abs(next-old)),"ADMIN_"+action.toUpperCase(Locale.ROOT));
                    balances.put(id,new AtomicLong(next)); names.put(id,name); return next;
                } catch(Exception e) { throw new CompletionException(e); }
            }
        },io);
    }
    public CompletableFuture<List<Map.Entry<String,Long>>> top(int limit,int offset) {
        return CompletableFuture.supplyAsync(() -> {
            List<Map.Entry<String,Long>> list=new ArrayList<>();
            try(Connection c=db.connection(); PreparedStatement p=c.prepareStatement("SELECT name,balance FROM accounts ORDER BY balance DESC LIMIT ? OFFSET ?")) {
                p.setInt(1,limit); p.setInt(2,offset); try(ResultSet r=p.executeQuery()){while(r.next()) list.add(Map.entry(r.getString(1),r.getLong(2)));}
            } catch(SQLException e){plugin.getLogger().warning("Baltop refresh failed: "+e.getMessage());}
            return list;
        },io);
    }
    public void flush() {
        for(var e:balances.entrySet()) try { db.save(e.getKey(),names.getOrDefault(e.getKey(),"Unknown"),e.getValue().get()); }
        catch(SQLException ex) { plugin.getLogger().severe("Balance flush failed for "+e.getKey()+": "+ex.getMessage()); }
    }
    public void shutdown() { flush(); io.shutdown(); try { if(!io.awaitTermination(5,TimeUnit.SECONDS)) io.shutdownNow(); } catch(InterruptedException e){Thread.currentThread().interrupt();io.shutdownNow();} }
}
