package net.hexamc.hexaeconomy;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class GUIManager implements Listener {
    public static final class Holder implements InventoryHolder {
        private final String type; private final Map<Integer,String> actions=new HashMap<>();
        public Holder(String type){this.type=type;}
        public String type(){return type;}
        public void action(int slot,String action){actions.put(slot,action);}
        public String action(int slot){return actions.get(slot);}
        @Override public Inventory getInventory(){return null;}
    }
    private final HexaEconomy plugin;
    private final Map<UUID,Long> lastClick=new ConcurrentHashMap<>();
    public GUIManager(HexaEconomy plugin){this.plugin=plugin; Bukkit.getPluginManager().registerEvents(this,plugin);}
    public Inventory create(Player p,int size,String title,String type){return Bukkit.createInventory(new Holder(type),size,ColorUtil.component(title));}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void click(InventoryClickEvent e){
        if(!(e.getView().getTopInventory().getHolder(false) instanceof Holder holder)) return;
        e.setCancelled(true);
        if(!(e.getWhoClicked() instanceof Player p)) return;
        long now=System.currentTimeMillis(), last=lastClick.getOrDefault(p.getUniqueId(),0L);
        if(now-last<150){p.updateInventory();return;}
        lastClick.put(p.getUniqueId(),now);
        if(e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory()){p.updateInventory();return;}
        String action=holder.action(e.getSlot());
        if(action!=null) plugin.handleGuiAction(p,holder.type(),action);
        p.updateInventory();
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void drag(InventoryDragEvent e){
        if(e.getView().getTopInventory().getHolder(false) instanceof Holder) {
            e.setCancelled(true);
            if(e.getWhoClicked() instanceof Player p) p.updateInventory();
        }
    }
    @EventHandler public void quit(org.bukkit.event.player.PlayerQuitEvent e){lastClick.remove(e.getPlayer().getUniqueId());}
}
