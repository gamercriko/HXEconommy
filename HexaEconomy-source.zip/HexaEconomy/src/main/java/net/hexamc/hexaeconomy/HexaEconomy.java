package net.hexamc.hexaeconomy;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

public final class HexaEconomy extends JavaPlugin implements Listener {
    private DatabaseManager database;
    private EconomyManager economy;
    private GUIManager guis;
    private ShopGUI shop;
    private SellGUI sell;
    private org.bukkit.configuration.file.FileConfiguration shopConfig;
    private final AtomicReference<List<Map.Entry<String,Long>>> baltop=new AtomicReference<>(List.of());
    private String prefix;
    @Override public void onEnable(){
        if(Runtime.version().feature()<25){getLogger().severe("HexaEconomy requires Java 25+ for Paper 26.2.");Bukkit.getPluginManager().disablePlugin(this);return;}
        saveDefaultConfig(); saveResource("shop.yml",false); saveResource("messages.yml",false);
        reloadShop(); prefix=getConfig().getString("messages.prefix","&#FBE700&l&o&nH&#C9E533&l&o&ne&#97E266&l&o&nx&#64E099&l&o&na&#32DDCC&l&o&nM&#00DBFF&l&o&nC");
        database=new DatabaseManager(this); economy=new EconomyManager(this,database); guis=new GUIManager(this); shop=new ShopGUI(this); sell=new SellGUI(this);
        Bukkit.getPluginManager().registerEvents(this,this);
        bind("bal",this::balanceCommand);bind("pay",this::payCommand);bind("eco",this::ecoCommand);bind("hexeconomy",this::adminCommand);bind("baltop",this::baltopCommand);bind("shop",(s,c,l)->{if(s instanceof Player p)shop.openMain(p);else s.sendMessage("Players only.");return true;});bind("sellgui",(s,c,l)->{if(s instanceof Player p)sell.open(p);else s.sendMessage("Players only.");return true;});
        long period=Math.max(60,getConfig().getLong("baltop-refresh-seconds",300));
        Bukkit.getScheduler().runTaskTimerAsynchronously(this,()->economy.top(100,0).thenAccept(baltop::set),20L,period*20L);
        getLogger().info("HexaEconomy enabled. Database health: "+database.healthy());
    }
    private void bind(String name,CommandExecutor ex){PluginCommand c=getCommand(name);if(c!=null)c.setExecutor(ex);}
    @Override public void onDisable(){if(economy!=null)economy.shutdown();if(database!=null)database.close();}
    @EventHandler public void prelogin(AsyncPlayerPreLoginEvent e){try{economy.load(e.getUniqueId(),e.getName()).join();}catch(Exception ex){getLogger().severe("Failed to load balance for "+e.getName()+": "+ex.getMessage());e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,"Economy data could not be loaded. Please retry.");}}
    @EventHandler public void join(PlayerJoinEvent e){economy.ensure(e.getPlayer());}
    public String prefix(){return prefix;}
    public EconomyManager economy(){return economy;}
    public GUIManager guis(){return guis;}
    public org.bukkit.configuration.file.FileConfiguration getConfigShop(){return shopConfig;}
    private void reloadShop(){shopConfig=org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(),"shop.yml"));}
    private String msg(String key){return org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(),"messages.yml")).getString(key,key);}
    private void send(CommandSender s,String text){s.sendMessage(ColorUtil.component(prefix+text));}
    private long amount(String s){BigDecimal d=new BigDecimal(s);if(d.scale()>2||d.signum()<=0)return -1;return d.movePointRight(2).longValueExact();}
    private boolean balanceCommand(CommandSender s,Command c,String label,String[] a){
        if(!(s instanceof Player p)){send(s," &cPlayers only.");return true;}
        if(a.length==0){send(p," Balance - $"+EconomyManager.money(economy.balance(p.getUniqueId())));return true;}
        if(!p.hasPermission("hexaeconomy.balance.others")){send(p," &cYou do not have permission.");return true;}
        OfflinePlayer target=Bukkit.getOfflinePlayer(a[0]); if(!target.hasPlayedBefore()&&!target.isOnline()){send(p," &cThat player has not joined this server before.");return true;}
        economy.ensure(target).thenAccept(b->Bukkit.getScheduler().runTask(this,()->send(p," Balance of "+Objects.toString(target.getName(),a[0])+" - $"+EconomyManager.money(b))));
        return true;
    }
    private boolean payCommand(CommandSender s,Command c,String l,String[] a){
        if(!(s instanceof Player p)||a.length!=2){send(s," &cUsage: /pay <player> <amount>");return true;}
        if(!p.hasPermission("hexaeconomy.pay")){send(p," &cYou do not have permission.");return true;}
        Player target=Bukkit.getPlayerExact(a[0]);if(target==null){send(p," &cThat player is not online.");return true;}
        if(target.getUniqueId().equals(p.getUniqueId())){send(p," &cYou cannot pay yourself.");return true;}
        long cents;try{cents=amount(a[1]);}catch(Exception ex){cents=-1;}if(cents<=0){send(p," &cEnter a valid amount greater than zero with at most 2 decimal places.");return true;}
        economy.transfer(p.getUniqueId(),p.getName(),target.getUniqueId(),target.getName(),cents).thenAccept(ok->Bukkit.getScheduler().runTask(this,()->{
            if(!ok){send(p," You do not have enough funds to complete this transaction.");return;}
            send(p," You sent $"+EconomyManager.money(cents)+" to "+target.getName()+".");send(target," You received $"+EconomyManager.money(cents)+" from "+p.getName()+".");
        }));return true;
    }
    private boolean ecoCommand(CommandSender s,Command c,String l,String[] a){
        if(!s.hasPermission("hexaeconomy.admin")){send(s," &cYou do not have permission.");return true;}
        if(a.length<3){send(s," &cUsage: /eco <give|take|set|reset> <player> <amount>");return true;}
        String action=a[0].toLowerCase(Locale.ROOT);OfflinePlayer t=Bukkit.getOfflinePlayer(a[1]);
        if(!t.hasPlayedBefore()&&!t.isOnline()){send(s," &cThat player has not joined this server before.");return true;}
        long cents=0;if(!action.equals("reset")){try{cents=amount(a[2]);}catch(Exception ex){cents=-1;}if(cents<0){send(s," &cInvalid amount.");return true;}}
        final long value=cents;economy.ensure(t).thenCompose(old->economy.modify(t.getUniqueId(),Objects.toString(t.getName(),a[1]),action,value)).thenAccept(next->Bukkit.getScheduler().runTask(this,()->send(s," Modified balance of "+a[1]+" by $"+EconomyManager.money(Math.abs(next-economy.balance(t.getUniqueId())))+"."))).exceptionally(ex->{getLogger().warning(ex.getMessage());return null;});return true;
    }
    private boolean adminCommand(CommandSender s,Command c,String l,String[] a){
        if(!s.hasPermission("hexaeconomy.admin")){send(s," &cYou do not have permission.");return true;}
        if(a.length==0){send(s," &cUsage: /hexeconomy <reload|version>");return true;}
        if(a[0].equalsIgnoreCase("reload")){reloadConfig();reloadShop();prefix=getConfig().getString("messages.prefix",prefix);send(s," &aConfiguration files reloaded.");}
        else if(a[0].equalsIgnoreCase("version"))send(s," &eHexaEconomy 1.0.0 &7| DB: "+(database.healthy()?"healthy":"unavailable")+" | Java "+Runtime.version().feature());
        return true;
    }
    private boolean baltopCommand(CommandSender s,Command c,String l,String[] a){
        int page=1;try{if(a.length>0)page=Math.max(1,Integer.parseInt(a[0]));}catch(Exception ignored){}
        List<Map.Entry<String,Long>> list=baltop.get();send(s," &6Balance Top &7(Page "+page+")");
        int start=(page-1)*10;if(start>=list.size()){send(s," &cNo cached entries on that page.");return true;}
        for(int i=start;i<Math.min(start+10,list.size());i++){var e=list.get(i);send(s," &e#"+(i+1)+" &f"+e.getKey()+" &7- &a$"+EconomyManager.money(e.getValue()));}return true;
    }
    public void handleGuiAction(Player p,String type,String action){
        try {
            if(action.equals("main")){shop.openMain(p);return;}
            if(action.startsWith("category:")){shop.openCategory(p,action.substring(9),0);return;}
            if(action.startsWith("page:")){String[] x=action.split(":");shop.openCategory(p,x[1],Integer.parseInt(x[2]));return;}
            if(action.startsWith("product:")){String[] x=action.split(":");ShopGUI.Product prod=shop.find(x[1],x[2]);if(prod!=null)shop.openQuantity(p,prod,x[1],Integer.parseInt(x[3]));return;}
            if(action.startsWith("buy:")){String[] x=action.split(":");shop.buy(p,x[1],x[2],Integer.parseInt(x[3]),Integer.parseInt(x[4]));return;}
            if(action.startsWith("confirm:")){
                String[] x=action.split(":");ShopGUI.Product prod=shop.find(x[1],x[2]);int qty=Integer.parseInt(x[3]);long total=Math.multiplyExact(prod.buy(),qty);
                if(economy.balance(p.getUniqueId())<total){send(p," You do not have enough funds to complete this transaction.");return;}
                Map<Integer,org.bukkit.inventory.ItemStack> left=p.getInventory().addItem(new org.bukkit.inventory.ItemStack(prod.material(),qty));
                if(!left.isEmpty()){send(p," &cMake inventory space before purchasing.");return;}
                economy.modify(p.getUniqueId(),p.getName(),"take",total).thenAccept(b->Bukkit.getScheduler().runTask(this,()->{send(p," &aSuccessfully purchased "+qty+"x "+prod.name()+" for $"+EconomyManager.money(total)+".");p.closeInventory();}));
                return;
            }
        }catch(Exception ex){getLogger().warning("GUI action failed: "+ex.getMessage());p.updateInventory();}
    }
}
