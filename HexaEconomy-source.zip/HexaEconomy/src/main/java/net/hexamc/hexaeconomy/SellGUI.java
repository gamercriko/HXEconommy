package net.hexamc.hexaeconomy;

import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.*;
import java.math.BigDecimal;
import java.util.*;

public final class SellGUI implements Listener {
    private final HexaEconomy plugin;
    public SellGUI(HexaEconomy plugin){this.plugin=plugin;Bukkit.getPluginManager().registerEvents(this,plugin);}
    public void open(Player p){
        Inventory inv=plugin.guis().create(p,54,plugin.prefix()+" &8Deposit Items to Sell","sellgui");
        p.openInventory(inv);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void close(InventoryCloseEvent e){
        if(!(e.getPlayer() instanceof Player p))return;
        if(!(e.getInventory().getHolder(false) instanceof GUIManager.Holder h)||!h.type().equals("sellgui"))return;
        long total=0; int count=0; List<ItemStack> refund=new ArrayList<>();
        ConfigurationSection cats=plugin.getConfigShop().getConfigurationSection("categories");
        for(ItemStack item:e.getInventory().getContents()){
            if(item==null||item.getType().isAir())continue;
            double price=-1;
            if(cats!=null) for(String cat:cats.getKeys(false)){
                ConfigurationSection sec=cats.getConfigurationSection(cat+".items."+item.getType().name());
                if(sec!=null){price=sec.getDouble("sell-price",0);break;}
            }
            if(price>0 && item.getEnchantments().isEmpty() && !item.hasItemMeta()){
                long unit=BigDecimal.valueOf(price).movePointRight(2).longValueExact();
                total=Math.addExact(total,Math.multiplyExact(unit,item.getAmount())); count+=item.getAmount();
            }else refund.add(item.clone());
        }
        if(total>0){
            final long earned=total; final int sold=count;
            plugin.economy().modify(p.getUniqueId(),p.getName(),"give",earned).whenComplete((b,err)->Bukkit.getScheduler().runTask(plugin,()->{
                if(err==null)p.sendMessage(ColorUtil.component(plugin.prefix()+" &aYou sold &f"+sold+" &aitems for &e$"+EconomyManager.money(earned)+"&a!"));
                else p.sendMessage(ColorUtil.component(plugin.prefix()+" &cSale failed; contact staff."));
            }));
        }
        for(ItemStack item:refund){Map<Integer,ItemStack> leftovers=p.getInventory().addItem(item);leftovers.values().forEach(left->p.getWorld().dropItemNaturally(p.getLocation(),left));}
    }
}
