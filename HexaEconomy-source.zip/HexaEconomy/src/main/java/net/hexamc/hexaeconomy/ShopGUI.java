package net.hexamc.hexaeconomy;

import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import java.math.BigDecimal;
import java.util.*;

public final class ShopGUI {
    private final HexaEconomy plugin;
    private final Map<UUID,Product> selected=new HashMap<>();
    public record Product(Material material,String name,long buy,long sell,String category) {}
    public ShopGUI(HexaEconomy plugin){this.plugin=plugin;}
    private ItemStack item(Material m,String name,List<String> lore){
        ItemStack i=new ItemStack(m); ItemMeta meta=i.getItemMeta(); meta.displayName(ColorUtil.component(name));
        if(lore!=null) meta.lore(lore.stream().map(ColorUtil::component).toList()); i.setItemMeta(meta); return i;
    }
    public void openMain(Player p){
        Inventory inv=plugin.guis().create(p,54,plugin.prefix()+" &8Shop","shop-main");
        for(int s=0;s<54;s++) if(s<9||s>=45||s%9==0||s%9==8) inv.setItem(s,item(Material.BLACK_STAINED_GLASS_PANE," ",List.of()));
        ConfigurationSection cats=plugin.getConfigShop().getConfigurationSection("categories"); if(cats==null)return;
        int[] slots={11,12,13,14,15,20,21,22,23,24,29,30,31,32,33}; int idx=0;
        for(String key:cats.getKeys(false)){if(idx>=slots.length)break; ConfigurationSection c=cats.getConfigurationSection(key);
            Material icon=Material.matchMaterial(c.getString("icon","CHEST")); if(icon==null)icon=Material.CHEST;
            inv.setItem(slots[idx],item(icon,"&e"+c.getString("name",key),List.of("&7Click to browse")));
            ((GUIManager.Holder)inv.getHolder(false)).action(slots[idx],"category:"+key); idx++;
        }
        p.openInventory(inv);
    }
    public void openCategory(Player p,String key,int page){
        ConfigurationSection cat=plugin.getConfigShop().getConfigurationSection("categories."+key); if(cat==null){openMain(p);return;}
        Inventory inv=plugin.guis().create(p,54,plugin.prefix()+" &8"+cat.getString("name","Shop"),"shop-category");
        ConfigurationSection items=cat.getConfigurationSection("items"); List<String> keys=items==null?List.of():new ArrayList<>(items.getKeys(false));
        int start=page*45;
        for(int i=0;i<45&&start+i<keys.size();i++){
            String matName=keys.get(start+i); ConfigurationSection sec=items.getConfigurationSection(matName); Material mat=Material.matchMaterial(matName); if(mat==null||sec==null)continue;
            Product prod=new Product(mat,sec.getString("name",mat.name()),cents(sec.getDouble("buy-price")),cents(sec.getDouble("sell-price")),key);
            inv.setItem(i,item(mat,"&f"+prod.name(),List.of("&7Buy: &a$"+EconomyManager.money(prod.buy()),"&7Sell: &c$"+EconomyManager.money(prod.sell()),"&eLeft-click to open buy menu")));
            ((GUIManager.Holder)inv.getHolder(false)).action(i,"product:"+key+":"+matName+":"+page);
        }
        inv.setItem(45,item(Material.RED_CONCRETE,"&cPrevious Page",List.of()));
        inv.setItem(49,item(Material.BARRIER,"&eBack to Main Categories",List.of()));
        inv.setItem(53,item(Material.GREEN_CONCRETE,"&aNext Page",List.of()));
        ((GUIManager.Holder)inv.getHolder(false)).action(45,"page:"+key+":"+Math.max(0,page-1));
        ((GUIManager.Holder)inv.getHolder(false)).action(49,"main");
        ((GUIManager.Holder)inv.getHolder(false)).action(53,"page:"+key+":"+(page+1));
        p.openInventory(inv);
    }
    public void openQuantity(Player p,Product prod,String category,int page){
        selected.put(p.getUniqueId(),prod);
        Inventory inv=plugin.guis().create(p,27,plugin.prefix()+" &8Buy "+prod.name(),"shop-quantity");
        inv.setItem(13,item(prod.material(),"&f"+prod.name(),List.of("&7Unit price: &a$"+EconomyManager.money(prod.buy()))));
        int[] slots={10,12,14,16}, qty={1,10,32,64};
        for(int i=0;i<4;i++){inv.setItem(slots[i],item(Material.GREEN_STAINED_GLASS_PANE,"&aBuy "+qty[i]+"x",List.of("&7Total: &e$"+EconomyManager.money(Math.multiplyExact(prod.buy(),qty[i])))));((GUIManager.Holder)inv.getHolder(false)).action(slots[i],"buy:"+category+":"+prod.material().name()+":"+qty[i]+":"+page);}
        inv.setItem(22,item(Material.ARROW,"&eBack to Category Items",List.of()));((GUIManager.Holder)inv.getHolder(false)).action(22,"page:"+category+":"+page);
        p.openInventory(inv);
    }
    public void openConfirm(Player p,Product prod,int qty,String category,int page){
        selected.put(p.getUniqueId(),prod);
        Inventory inv=plugin.guis().create(p,27,plugin.prefix()+" &8Confirm Purchase","shop-confirm");
        long total=Math.multiplyExact(prod.buy(),qty);
        inv.setItem(13,item(prod.material(),"&f"+prod.name(),List.of("&7Quantity: &f"+qty,"&7Total: &e$"+EconomyManager.money(total))));
        inv.setItem(11,item(Material.GREEN_STAINED_GLASS_PANE,"&a&lCONFIRM PURCHASE",List.of())); inv.setItem(15,item(Material.RED_STAINED_GLASS_PANE,"&c&lCANCEL TRANSACTION",List.of()));
        ((GUIManager.Holder)inv.getHolder(false)).action(11,"confirm:"+category+":"+prod.material().name()+":"+qty+":"+page);
        ((GUIManager.Holder)inv.getHolder(false)).action(15,"page:"+category+":"+page);
        p.openInventory(inv);
    }
    public void buy(Player p,String category,String material,int qty,int page){
        Product prod=find(category,material); if(prod!=null)openConfirm(p,prod,qty,category,page);
    }
    public Product find(String category,String matName){
        ConfigurationSection s=plugin.getConfigShop().getConfigurationSection("categories."+category+".items."+matName); Material m=Material.matchMaterial(matName);
        return s==null||m==null?null:new Product(m,s.getString("name",matName),cents(s.getDouble("buy-price")),cents(s.getDouble("sell-price")),category);
    }
    private long cents(double d){return BigDecimal.valueOf(d).movePointRight(2).longValueExact();}
}
